﻿using System;
using System.Text;
using System.Threading.Tasks;
using Azure.Storage.Blobs;
using Azure.Messaging.EventHubs;
using Azure.Messaging.EventHubs.Consumer;
using Azure.Messaging.EventHubs.Processor;

namespace EventHubzReceiver
{

    class Program
    {
        private static string ehubNamespaceConnectionString;
        private static string eventHubName;
        private static string blobStorageConnectionString;
        private static string blobContainerName;

        // Read from the default consumer group: $Default
        private static string consumerGroup = EventHubConsumerClient.DefaultConsumerGroupName;

        static async Task Main()
        {
            if (true)
            {
                ehubNamespaceConnectionString = "Endpoint=sb://eventhubnspace.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=iUOla1+ZcsFGnWN57Zqbhol9LJtx488qnnIrx2RN5cE=";
                eventHubName = "eventhubfirst";
                blobStorageConnectionString = "DefaultEndpointsProtocol=https;AccountName=version2sa;AccountKey=ilLJJpRHdy0v678U7sSa3NaX6++fmVD8XJskx8M+T3rB+LbXYoOWGqMfjBO6+MQzYdOElUXsX4wtYiCmtG2aSQ==;EndpointSuffix=core.windows.net";
                blobContainerName = "ehubblob";
            }
            else
            {
                ehubNamespaceConnectionString = "Endpoint=sb://qolodevehub.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=Aw1BIkq20vBopL/6SXJkJZD0oP+WG4RD8RR4kGTI1k0=";
                eventHubName = "tmoutsortehub";
                blobStorageConnectionString = "DefaultEndpointsProtocol=https;AccountName=qolodevbatch;AccountKey=MDmTeBRlPIBJWA4UU6UR/e04E/zc+SmKBZAlAJ1eflFhdNqe9E873vf7iyNXyETyjoC0EP6vooeVs/oiSJjBJQ==;EndpointSuffix=core.windows.net";
                blobContainerName = "ehubcontainer";
            }

            // Create a blob container client that the event processor will use 
            BlobContainerClient storageClient = new BlobContainerClient(blobStorageConnectionString, blobContainerName);

            // Create an event processor client to process events in the event hub
            EventProcessorClient processor = new EventProcessorClient(storageClient, consumerGroup, ehubNamespaceConnectionString, eventHubName);

            // Register handlers for processing events and handling errors
            processor.ProcessEventAsync += ProcessEventHandler;
            processor.ProcessErrorAsync += ProcessErrorHandler;

            // Start the processing
            await processor.StartProcessingAsync();

            // Wait for 10 seconds for the events to be processed
            await Task.Delay(TimeSpan.FromSeconds(5));

            // Stop the processing
            await processor.StopProcessingAsync();
        }
        static async Task ProcessEventHandler(ProcessEventArgs eventArgs)
        {
            // Write the body of the event to the console window
            Console.WriteLine("\tReceived event: {0}", Encoding.UTF8.GetString(eventArgs.Data.Body.ToArray()));

            // Update checkpoint in the blob storage so that the app receives only new events the next time it's run
            await eventArgs.UpdateCheckpointAsync(eventArgs.CancellationToken);
        }

        static Task ProcessErrorHandler(ProcessErrorEventArgs eventArgs)
        {
            // Write details about the error to the console window
            Console.WriteLine($"\tPartition '{ eventArgs.PartitionId}': an unhandled exception was encountered. This was not expected to happen.");
            Console.WriteLine(eventArgs.Exception.Message);
            Console.WriteLine(eventArgs);
            return Task.CompletedTask;
        }
    }
}
