﻿using System;
using System.Text;
using System.Threading.Tasks;
using Azure.Messaging.EventHubs;
using Azure.Messaging.EventHubs.Producer;
using Newtonsoft.Json;

namespace EventHubSender
{
    class Program
    {
        private static string connectionString;
        private static string eventHubName;

        static async Task Main()
            {
                if (true)
                {
                    connectionString = "Endpoint=sb://eventhubnspace.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=iUOla1+ZcsFGnWN57Zqbhol9LJtx488qnnIrx2RN5cE=";
                    eventHubName = "eventhubfirst";
                }
                else
                {
                    connectionString = "Endpoint=sb://qolodevehub.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=Aw1BIkq20vBopL/6SXJkJZD0oP+WG4RD8RR4kGTI1k0=";
                    eventHubName = "tmoutsortehub";
                }

                // Create a producer client that you can use to send events to an event hub
                await using (var producerClient = new EventHubProducerClient(connectionString, eventHubName))
                {
                    try
                    {
                        // Create a batch of events 
                        using EventDataBatch eventBatch = await producerClient.CreateBatchAsync();

                        // Add events to the batch. An event is a represented by a collection of bytes and metadata. 
                        var outsort = new TMOutsortData
                        {
                            request_code = "ST-PURCHASE",
                            person_guid = Guid.NewGuid(),
                            model_name = "sabrina 1",
                            //source_code = ,
                            source_user_guid = Guid.NewGuid()
                        };
                        eventBatch.TryAdd(new EventData(Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(outsort))));

                        outsort = new TMOutsortData
                        {
                            request_code = "ST-PURCHASE",
                            person_guid = Guid.NewGuid(),
                            model_name = "test 2",
                            //source_code = ,
                            source_user_guid = Guid.NewGuid()
                        };
                        eventBatch.TryAdd(new EventData(Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(outsort))));

                        outsort = new TMOutsortData
                        {
                            request_code = "ST-PURCHASE",
                            person_guid = Guid.NewGuid(),
                            model_name = "test 3",
                            //source_code = ,
                            source_user_guid = Guid.NewGuid()
                        };
                        eventBatch.TryAdd(new EventData(Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(outsort))));

                        // Use the producer client to send the batch of events to the event hub
                        await producerClient.SendAsync(eventBatch);
                        Console.WriteLine("A batch of 3 events has been published.");
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e.Message);
                    }
                }
            }
        }



    public class TMOutsortData
    {
        public string request_code { get; set; }
        public Guid? txn_guid { get; set; }
        public Guid person_guid { get; set; }
        public Guid? account_guid { get; set; }
        public Guid? acquire_txn_guid { get; set; }
        public Guid? bank_eft_guid { get; set; }
        public Guid? payment_guid { get; set; }
        public Guid? card_auth_txn_guid { get; set; }
        public Guid? card_settle_txn_guid { get; set; }
        public string model_name { get; set; }
        public string source_code { get; set; }
        public Guid source_user_guid { get; set; }
        public Guid? wallet_guid { get; set; }
        public string card_proxy { get; set; }
        public Guid? program_guid { get; set; }
    }
}
